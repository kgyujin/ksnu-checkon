import { NextResponse } from 'next/server';

interface RequestBody {
  bizNumber?: string;
  ftcNumber?: string;
  brandName?: string;
}

export async function POST(request: Request) {
  try {
    const body: RequestBody = await request.json();
    const { bizNumber, ftcNumber, brandName } = body;
    
    if (!bizNumber && !ftcNumber) {
      return NextResponse.json({
        success: false,
        message: '사업자등록번호 또는 통신판매업신고번호 중 최소 하나가 필요합니다.'
      }, { status: 400 });
    }

    let cleanBizNum = '';
    let cleanFtcNum = '';
    let ntsResult: any = { isValid: false, message: '조회 불가' };
    let ftcResult: any = { status: '정보 없음', message: '정보 없음' };
    let kiprisResult: any = { status: '정보 없음', message: '' };
    let businessInfo: any = {};

    // 1. 사업자등록번호로 조회 (국세청)
    if (bizNumber) {
      cleanBizNum = bizNumber.replace(/-/g, ''); // 하이픈 제거
      ntsResult = await handleNTS(cleanBizNum);
      
      // 사업자등록번호 조회 성공 시 기본 정보 수집
      if (ntsResult.isValid || ntsResult.data) {
        businessInfo.bizNumber = cleanBizNum;
        businessInfo.ntsStatus = ntsResult.message;
        
        // NTS에서 받은 데이터 추가 (status 엔드포인트는 제한된 정보만 제공)
        if (ntsResult.data && Object.keys(ntsResult.data).length > 0) {
          businessInfo.taxType = ntsResult.data.tax_type || '';
          businessInfo.rBfTaxType = ntsResult.data.rbf_tax_type || '';
          businessInfo.utccYn = ntsResult.data.utcc_yn || '';
          businessInfo.invoiceApplyDt = ntsResult.data.invoice_apply_dt || '';
          businessInfo.bSttCd = ntsResult.data.b_stt_cd || '';
          businessInfo.taxTypeChangeDate = ntsResult.data.tax_type_change_dt || '';
          businessInfo.endDate = ntsResult.data.end_dt || '';
        }
      }
    }

    // 2. 통신판매업신고번호로 조회 (공정위)
    if (ftcNumber) {
      cleanFtcNum = ftcNumber.replace(/-/g, '');
      ftcResult = await handleFTC(cleanFtcNum);
      businessInfo.ftcNumber = cleanFtcNum;
      businessInfo.ftcStatus = ftcResult.message;
    } else if (bizNumber && ntsResult.isValid) {
      // 통신판매업신고번호가 없으면, 사업자등록번호로 공정위 조회
      ftcResult = await handleFTC(cleanBizNum);
      businessInfo.ftcStatus = ftcResult.message;
    }

    // 3. 특허청 (KIPRIS) 처리 (상표명이 있을 때만)
    if (brandName) {
      kiprisResult = await handleKIPRIS(brandName);
      businessInfo.brandName = brandName;
      businessInfo.kiprisStatus = kiprisResult.message;
    }

    // 4. 신뢰도 점수 계산
    const safetyScore = calculateSafetyScore(ntsResult, ftcResult, kiprisResult);

    // 5. 최종 결과 반환
    return NextResponse.json({
      success: true,
      data: {
        bizStatus: ntsResult.message,
        onlineLicense: ftcResult.message,
        brandRight: kiprisResult.message,
        safetyScore: safetyScore,
        businessInfo: businessInfo,
        summary: ntsResult.isValid
          ? '✅ 국세청 등록 정보가 확인되었습니다.'
          : (ftcResult.status === 'OK' ? '⚠️ 공정위 통신판매업 신고 정보는 확인되었으나 국세청 등록 정보 없음' : '⚠️ 국세청에 등록되지 않았거나 휴/폐업된 사업자입니다.')
      }
    });

  } catch (error) {
    console.error('Server Error:', error);
    return NextResponse.json({ success: false, message: '서버 내부 오류' }, { status: 500 });
  }
}

// =================================================================
// 1. 국세청 (NTS) 핸들러 - /status 엔드포인트 사용 (상태조회)
// =================================================================
async function handleNTS(cleanBizNum: string) {
  const isMock = process.env.USE_MOCK_NTS === 'true';

  if (isMock) {
    console.log('📢 [NTS] Mock 모드 실행');
    const isActive = parseInt(cleanBizNum) % 2 === 0; 
    return {
      isValid: isActive,
      message: isActive ? '[TEST] 계속사업자(01)' : '[TEST] 폐업자(03)',
      data: {
        b_stt: isActive ? '계속사업자' : '폐업자',
        b_stt_cd: isActive ? '01' : '03',
        b_nm: '[TEST] 테스트 회사명',
        p_nm: '[TEST] 홍길동',
        b_addr: '[TEST] 테스트 주소',
        b_sector: '[TEST] 제조업',
        b_type: '[TEST] 영리법인의 본점',
        tax_type: '[TEST] 부가가치세 일반과세자',
        utcc_yn: 'Y',
        start_dt: '20200101'
      }
    };
  } else {
    console.log('🚀 [NTS] 실제 API 호출 (/status 엔드포인트)');
    const apiKey = process.env.NTS_API_KEY;
    
    if (!apiKey) {
      console.error('❌ NTS_API_KEY 환경변수가 설정되지 않았습니다');
      return { 
        isValid: false, 
        message: 'API 키 설정 오류', 
        data: {} 
      };
    }

    const url = `https://api.odcloud.kr/api/nts-businessman/v1/status?serviceKey=${apiKey}`;

    try {
      console.log('📤 NTS API 요청:', { b_no: cleanBizNum });
      
      const res = await fetch(url, {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Accept': 'application/json' 
        },
        body: JSON.stringify({ "b_no": [cleanBizNum] })
      });

      console.log('📥 NTS API 응답 상태:', res.status);
      
      if (!res.ok) {
        const errorText = await res.text();
        console.error(`NTS API Error ${res.status}:`, errorText);
        
        if (res.status === 404) {
          return { 
            isValid: false, 
            message: '국세청에 등록되지 않은 사업자등록번호입니다', 
            data: {} 
          };
        } else if (res.status === 400 || res.status === 411) {
          return { 
            isValid: false, 
            message: '잘못된 요청 형식입니다', 
            data: {} 
          };
        } else {
          return { 
            isValid: false, 
            message: `국세청 API 오류 (${res.status})`, 
            data: {} 
          };
        }
      }

      const result = await res.json();
      console.log('📊 NTS API 응답 데이터:', result);
      
      if (!result.data || result.data.length === 0) {
        return { 
          isValid: false, 
          message: '조회 결과 없음', 
          data: {} 
        };
      }

      const item = result.data[0];
      
      // b_stt_cd가 비어있으면 조회 실패 (등록되지 않은 사업자)
      if (!item.b_stt_cd || item.b_stt_cd === '') {
        return { 
          isValid: false, 
          message: '국세청에 등록되지 않은 사업자등록번호입니다', 
          data: {} 
        };
      }

      const isValid = item.b_stt_cd === '01'; // '01' = 계속사업자
      
      return {
        isValid: isValid,
        message: item.b_stt || '상태 알 수 없음',
        data: {
          b_stt: item.b_stt || '',
          b_stt_cd: item.b_stt_cd || '',
          tax_type: item.tax_type && !item.tax_type.includes('등록되지 않은') ? item.tax_type : '',
          tax_type_cd: item.tax_type_cd || '',
          rbf_tax_type: item.rbf_tax_type && item.rbf_tax_type !== '해당없음' ? item.rbf_tax_type : '',
          rbf_tax_type_cd: item.rbf_tax_type_cd || '',
          utcc_yn: item.utcc_yn || '',
          invoice_apply_dt: item.invoice_apply_dt || '',
          end_dt: item.end_dt || '',
          tax_type_change_dt: item.tax_type_change_dt || ''
        }
      };
    } catch (e) {
      console.error('NTS Fetch Error:', e);
      return { 
        isValid: false, 
        message: '조회 실패 (네트워크 오류)', 
        data: {} 
      };
    }
  }
}

// =================================================================
// 2. 공정위 (FTC) 핸들러 (사업자등록번호 또는 통신판매업신고번호로 조회)
// =================================================================
async function handleFTC(searchValue: string) {
  const isMock = process.env.USE_MOCK_FTC === 'true';

  if (isMock) {
    console.log('📢 [FTC] Mock 모드 실행');
    return { status: 'OK', message: '[TEST] 통신판매업 신고 확인됨' };
  } else {
    console.log('🚀 [FTC] 실제 API 호출 시도');
    const apiKey = process.env.FTC_API_KEY;

    // [PDF 소스 377, 382] 기반의 정확한 URL
    const baseUrl = 'https://apis.data.go.kr/1130000/MllBsDtl_3Service/getMllBsInfoDetail_3';
    
    const params = new URLSearchParams({
        serviceKey: apiKey || '', 
        pageNo: '1',            // [PDF 소스 393] 필수
        numOfRows: '1',         // [PDF 소스 398] 필수
        resultType: 'json',     // [PDF 소스 404] JSON 요청
        brno: searchValue       // [PDF 소스 421] 사업자등록번호 또는 통신판매업신고번호 파라미터
    });

    try {
        // 타임아웃 15초 설정 (서버 지연 대응)
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 15000);

        const res = await fetch(`${baseUrl}?${params.toString()}`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
            signal: controller.signal
        });
        
        clearTimeout(timeoutId);

        if (res.ok) {
            const data = await res.json();
            
            // 응답 구조 유연하게 처리 (JSON 구조가 다를 수 있음)
            const items = data.items || data.response?.body?.items || data.getMllBsInfoDetail_3?.items;
            
            // 데이터가 배열이든 객체든 존재하면 '신고됨'으로 간주
            if (items && (Array.isArray(items) ? items.length > 0 : items)) {
                 return { status: 'OK', message: '통신판매업 신고 확인됨' };
            } else {
                 return { status: 'NONE', message: '통신판매업 내역 없음 (주의)' };
            }
        } else {
            console.error(`FTC API Error: ${res.status}`);
            return { status: 'ERROR', message: '공정위 서버 응답 없음' };
        }
    } catch (e: any) {
        if (e.name === 'AbortError') {
            console.error('FTC Timeout: 15초 초과');
            return { status: 'TIMEOUT', message: '공정위 조회 시간 초과 (서버 지연)' };
        }
        console.error('FTC Fetch Error:', e);
        return { status: 'ERROR', message: 'API 연결 오류' };
    }
  }
}

// =================================================================
// 3. 특허청 (KIPRIS) 핸들러
// =================================================================
async function handleKIPRIS(brandName: string) {
  const isMock = process.env.USE_MOCK_KIPRIS === 'true';

  if (isMock) {
    return { 
      status: 'Test', 
      message: brandName.includes('체크온') ? '[TEST] 상표권 등록됨' : '[TEST] 등록 정보 없음' 
    };
  } else {
    return { status: 'Unknown', message: 'API 키 미발급 상태' };
  }
}

// =================================================================
// 4. 신뢰도 점수 계산 함수
// =================================================================
// 로직: 국세청(50점) + 공정위(30점) + 특허청(20점, 없으면 0점) = 총 100점 만점
function calculateSafetyScore(
  ntsResult: any,
  ftcResult: any,
  kiprisResult: any
): { score: number; breakdown: { nts: number; ftc: number; kipris: number } } {
  let score = 0;

  // 국세청: 50점 (사업자 상태 확인)
  const ntsScore = ntsResult.isValid ? 50 : 0;
  score += ntsScore;

  // 공정위: 30점 (통신판매업 신고 확인)
  const ftcScore = ftcResult.message.includes('확인됨') ? 30 : 0;
  score += ftcScore;

  // 특허청: 20점 (상표권 등록)
  const kiprisScore = kiprisResult.message.includes('등록') || kiprisResult.message.includes('있음') ? 20 : 0;
  score += kiprisScore;

  return {
    score: Math.max(0, Math.min(100, score)),
    breakdown: {
      nts: ntsScore,
      ftc: ftcScore,
      kipris: kiprisScore
    }
  };
}