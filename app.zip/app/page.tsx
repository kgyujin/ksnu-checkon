'use client';

import { useState } from 'react';

export default function Home() {
  const [bizNum, setBizNum] = useState('');
  const [ftcNum, setFtcNum] = useState('');
  const [brand, setBrand] = useState('');
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [loadingStep, setLoadingStep] = useState(0);

  const loadingSteps = [
    '🏢 국세청 데이터 조회 중...',
    '⚖️ 공정위 통신판매업 검증 중...',
    '®️ 특허청 상표권 분석 중...',
    '📊 신뢰도 점수 최종 계산 중...'
  ];

  const handleCheck = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!bizNum && !ftcNum) {
      alert('사업자등록번호 또는 통신판매업신고번호 중 최소 하나를 입력해주세요.');
      return;
    }

    setLoading(true);
    setResult(null);
    setLoadingStep(0);

    const stepInterval = setInterval(() => {
      setLoadingStep((prev) => {
        const next = prev + 1;
        if (next >= loadingSteps.length) {
          return prev;
        }
        return next;
      });
    }, 1500);

    try {
      const res = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          bizNumber: bizNum || undefined, 
          ftcNumber: ftcNum || undefined,
          brandName: brand || undefined 
        }),
      });
      const data = await res.json();
      if (data.success !== false) {
        setResult(data.data);
      } else {
        alert(data.message || '조회 실패');
      }
    } catch (error) {
      alert('분석 중 오류가 발생했습니다. 잠시 후 다시 시도해주세요.');
    } finally {
      clearInterval(stepInterval);
      setLoading(false);
    }
  };

  return (
    <main className="min-h-screen flex flex-col items-center justify-start pt-8 pb-16 p-4 relative">
      {/* 배경 장식 (Background Blobs) */}
      <div className="absolute top-0 left-0 w-full h-96 bg-gradient-to-b from-indigo-100 to-transparent -z-10 opacity-70"></div>
      <div className="absolute top-[-10%] right-[-5%] w-72 h-72 bg-blue-200 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob"></div>
      <div className="absolute top-[-10%] left-[-5%] w-72 h-72 bg-purple-200 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob animation-delay-2000"></div>

      <div className="max-w-2xl w-full">
        {/* 헤더 섹션 */}
        <div className="text-center mb-10">
          <span className="inline-block py-1 px-3 rounded-full bg-blue-50 text-blue-600 text-xs font-bold tracking-wider mb-3 border border-blue-100">
            BUSINESS VERIFICATION
          </span>
          <h1 className="text-4xl md:text-5xl font-extrabold text-slate-900 tracking-tight mb-3">
            CheckOn
          </h1>
          <p className="text-slate-500 text-lg font-medium">
            데이터로 증명하는 가장 확실한 신뢰
          </p>
        </div>

        {/* 메인 카드 */}
        <div className="bg-white/80 backdrop-blur-xl rounded-2xl shadow-2xl border border-white/50 p-8 md:p-10 transition-all duration-300 hover:shadow-3xl">
          <form onSubmit={handleCheck} className="space-y-6">
            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-700 ml-1">사업자등록번호 <span className="text-slate-400 font-normal">(선택)</span></label>
              <div className="relative">
                <input 
                  type="text" 
                  value={bizNum}
                  onChange={(e) => setBizNum(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3.5 text-[#121212] font-medium focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all placeholder:text-slate-400"
                  placeholder="예: 1234567890"
                />
                <div className="absolute right-4 top-3.5 text-slate-400">
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 21h19.5m-18-18v18m10.5-18v18m6-13.5V21M6.75 6.75h.75m-.75 3h.75m-.75 3h.75m3-6h.75m-.75 3h.75m-.75 3h.75M6.75 21v-3.375c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21M3 3h12m-.75 4.5H21m-3.75 3.75h.008v.008h-.008v-.008Zm0 3h.008v.008h-.008v-.008Zm0 3h.008v.008h-.008v-.008Z" />
                  </svg>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-700 ml-1">통신판매업신고번호 <span className="text-slate-400 font-normal">(선택)</span></label>
              <div className="relative">
                <input 
                  type="text" 
                  value={ftcNum}
                  onChange={(e) => setFtcNum(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3.5 text-[#121212] font-medium focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all placeholder:text-slate-400"
                  placeholder="예: 2024-12345"
                />
                <div className="absolute right-4 top-3.5 text-slate-400">
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
              </div>
              <p className="text-xs text-slate-500">사업자등록번호 또는 통신판매업신고번호 중 최소 하나를 입력해주세요</p>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-semibold text-slate-700 ml-1">상표명 <span className="text-slate-400 font-normal">(선택)</span></label>
              <div className="relative">
                <input 
                  type="text" 
                  value={brand}
                  onChange={(e) => setBrand(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3.5 text-[#121212] font-medium focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none transition-all placeholder:text-slate-400"
                  placeholder="예: 체크온"
                />
                <div className="absolute right-4 top-3.5 text-slate-400">
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 21v-7.5a.75.75 0 0 1 .75-.75h3a.75.75 0 0 1 .75.75V21m-4.5 0H2.36m11.14 0H18m0 0h3.64m-1.39 0V9.349m-16.5 11.65V9.35m0 0a3.001 3.001 0 0 0 3.75-.615A2.993 2.993 0 0 0 9.75 9.75c.896 0 1.7-.393 2.25-1.016a2.993 2.993 0 0 0 2.25 1.016c.896 0 1.7-.393 2.25-1.016a3.001 3.001 0 0 0 3.75.614m-16.5 0a3.004 3.004 0 0 1-.621-4.72l1.189-1.19A1.5 1.5 0 0 1 5.378 3h13.243a1.5 1.5 0 0 1 1.06.44l1.19 1.189a3 3 0 0 1-.621 4.72m-13.5 8.65h3.75a.75.75 0 0 0 .75-.75V13.5a.75.75 0 0 0-.75-.75H6.75a.75.75 0 0 0-.75.75v3.75c0 .415.336.75.75.75Z" />
                  </svg>
                </div>
              </div>
            </div>

            <button 
              type="submit" 
              disabled={loading}
              className={`w-full py-4 rounded-xl font-bold text-lg text-white shadow-lg transform transition-all duration-200 active:scale-[0.98]
                ${loading 
                  ? 'bg-slate-400 cursor-not-allowed' 
                  : 'bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 hover:shadow-blue-500/25'
                }`}
            >
              {loading ? (
                <div className="flex items-center justify-center space-x-2">
                  <svg className="animate-spin h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  <span>{loadingSteps[loadingStep]}</span>
                </div>
              ) : (
                '신뢰도 무료 진단하기'
              )}
            </button>
          </form>
        </div>

        {/* 결과 리포트 섹션 */}
        {result && (
          <div className="mt-8 animate-fade-in-up">
            <div className="bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-100">
              {/* 상단: 점수 및 상태 */}
              <div className="bg-slate-50 p-8 border-b border-slate-100">
                <div className="flex flex-col items-center">
                  <SafetyScoreDisplay score={result.safetyScore} />
                  <p className="mt-6 text-center text-slate-600 font-medium leading-relaxed">
                    {result.summary}
                  </p>
                </div>
              </div>

              {/* 하단: 상세 리스트 */}
              <div className="p-6">
                <h3 className="text-sm font-bold text-slate-400 uppercase tracking-wider mb-4">
                  Detailed Analysis
                </h3>
                <div className="space-y-3">
                  <ResultItem 
                    label="국세청 사업자 상태" 
                    value={result.bizStatus} 
                    isGood={result.bizStatus.includes('계속') || result.bizStatus.includes('정상')}
                    icon="🏢"
                  />
                  <ResultItem 
                    label="공정위 통신판매업" 
                    value={result.onlineLicense} 
                    isGood={result.onlineLicense.includes('확인됨')}
                    icon="⚖️"
                  />
                  <ResultItem 
                    label="특허청 상표권" 
                    value={result.brandRight} 
                    isGood={result.brandRight.includes('있음') || result.brandRight.includes('등록')}
                    icon="®️"
                  />
                </div>

                {/* 사업자 정보 */}
                {result.businessInfo && Object.values(result.businessInfo).some((v: any) => v) && (
                  <div className="mt-6 pt-6 border-t border-slate-100">
                    <h4 className="text-lg font-bold text-slate-900 mb-4">📋 사업자 상세 정보</h4>
                    <div className="space-y-4">
                      {/* 회사명 - 강조 표시 */}
                      {result.businessInfo.corpName && (
                        <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-4 border border-blue-100">
                          <div className="text-xs text-slate-500 font-semibold mb-1 uppercase tracking-wider">Company Name</div>
                          <div className="text-xl font-bold text-slate-900">{result.businessInfo.corpName}</div>
                        </div>
                      )}
                      
                      {/* 주요 번호들 */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {result.businessInfo.bizNumber && (
                          <div className="bg-slate-50 rounded-lg p-3 border border-slate-200">
                            <div className="text-xs text-slate-500 font-semibold mb-1">사업자등록번호</div>
                            <div className="font-mono text-sm font-bold text-slate-800">{result.businessInfo.bizNumber}</div>
                          </div>
                        )}
                        {result.businessInfo.corpNo && (
                          <div className="bg-slate-50 rounded-lg p-3 border border-slate-200">
                            <div className="text-xs text-slate-500 font-semibold mb-1">법인등록번호</div>
                            <div className="font-mono text-sm font-bold text-slate-800">{result.businessInfo.corpNo}</div>
                          </div>
                        )}
                        {result.businessInfo.ftcNumber && (
                          <div className="bg-slate-50 rounded-lg p-3 border border-slate-200">
                            <div className="text-xs text-slate-500 font-semibold mb-1">통신판매신고번호</div>
                            <div className="font-mono text-sm font-bold text-slate-800">{result.businessInfo.ftcNumber}</div>
                          </div>
                        )}
                      </div>

                      {/* 대표자 정보 */}
                      {result.businessInfo.representative && (
                        <div className="bg-slate-50 rounded-lg p-3 border border-slate-200">
                          <div className="text-xs text-slate-500 font-semibold mb-1">대표자명</div>
                          <div className="text-sm font-semibold text-slate-800">{result.businessInfo.representative}</div>
                        </div>
                      )}

                      {/* 주소 */}
                      {result.businessInfo.address && (
                        <div className="bg-slate-50 rounded-lg p-3 border border-slate-200">
                          <div className="text-xs text-slate-500 font-semibold mb-1">사업장 주소</div>
                          <div className="text-sm text-slate-800">{result.businessInfo.address}</div>
                        </div>
                      )}

                      {/* 사업 분류 */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {result.businessInfo.businessType && (
                          <div className="bg-slate-50 rounded-lg p-3 border border-slate-200">
                            <div className="text-xs text-slate-500 font-semibold mb-1">사업유형</div>
                            <div className="text-sm text-slate-800">{result.businessInfo.businessType}</div>
                          </div>
                        )}
                        {result.businessInfo.businessSector && (
                          <div className="bg-slate-50 rounded-lg p-3 border border-slate-200">
                            <div className="text-xs text-slate-500 font-semibold mb-1">사업분야</div>
                            <div className="text-sm text-slate-800">{result.businessInfo.businessSector}</div>
                          </div>
                        )}
                      </div>

                      {/* 세금 관련 정보 */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {result.businessInfo.taxType && (
                          <div className="bg-slate-50 rounded-lg p-3 border border-slate-200">
                            <div className="text-xs text-slate-500 font-semibold mb-1">현재 과세 유형</div>
                            <div className="text-sm text-slate-800">{result.businessInfo.taxType}</div>
                          </div>
                        )}
                        {result.businessInfo.rBfTaxType && result.businessInfo.rBfTaxType !== result.businessInfo.taxType && (
                          <div className="bg-amber-50 rounded-lg p-3 border border-amber-200">
                            <div className="text-xs text-slate-500 font-semibold mb-1">직전 과세 유형</div>
                            <div className="text-sm text-slate-800">{result.businessInfo.rBfTaxType}</div>
                          </div>
                        )}
                      </div>

                      {/* 기타 정보 */}
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-2 text-xs">
                        {result.businessInfo.startDt && (
                          <div className="bg-slate-50 rounded p-2">
                            <div className="text-slate-500 font-semibold">개업일</div>
                            <div className="text-slate-700 font-mono">{result.businessInfo.startDt}</div>
                          </div>
                        )}
                        {result.businessInfo.utccYn && (
                          <div className="bg-slate-50 rounded p-2">
                            <div className="text-slate-500 font-semibold">세금계산서</div>
                            <div className="text-slate-700">{result.businessInfo.utccYn === 'Y' ? '✅ 가능' : '❌ 불가'}</div>
                          </div>
                        )}
                        {result.businessInfo.invoiceApplyDt && (
                          <div className="bg-slate-50 rounded p-2">
                            <div className="text-slate-500 font-semibold">세금계산서 신청일</div>
                            <div className="text-slate-700 font-mono">{result.businessInfo.invoiceApplyDt}</div>
                          </div>
                        )}
                      </div>

                      {/* 상표명 */}
                      {result.businessInfo.brandName && (
                        <div className="bg-slate-50 rounded-lg p-3 border border-slate-200">
                          <div className="text-xs text-slate-500 font-semibold mb-1">등록된 상표명</div>
                          <div className="text-sm text-slate-700">{result.businessInfo.brandName}</div>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>
              
              {/* 푸터 */}
              <div className="bg-slate-50 px-6 py-4 border-t border-slate-100 flex justify-between items-center">
                <span className="text-xs text-slate-400 font-medium">Verified by CheckOn System</span>
                <span className="text-xs text-slate-300">{new Date().toLocaleDateString()}</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </main>
  );
}

// 점수 시각화 컴포넌트
function SafetyScoreDisplay({ score }: { score: { score: number; breakdown: { nts: number; ftc: number; kipris: number } } }) {
  const totalScore = score.score;
  const circumference = 2 * Math.PI * 50; 
  const strokeDashoffset = circumference - (totalScore / 100) * circumference;
  
  let colorClass = 'text-rose-500';
  let strokeColor = '#f43f5e'; // rose-500
  let statusText = 'Risk Detected';

  if (totalScore >= 50) {
    colorClass = 'text-amber-500';
    strokeColor = '#f59e0b'; // amber-500
    statusText = 'Moderate Safety';
  }
  if (totalScore >= 80) {
    colorClass = 'text-emerald-500';
    strokeColor = '#10b981'; // emerald-500
    statusText = 'High Safety';
  }

  return (
    <div className="relative">
      {/* 원형 차트 */}
      <div className="relative w-48 h-48">
        <svg className="w-full h-full transform -rotate-90 drop-shadow-lg" viewBox="0 0 120 120">
          <circle cx="60" cy="60" r="50" fill="none" stroke="#f1f5f9" strokeWidth="8" />
          <circle 
            cx="60" 
            cy="60" 
            r="50" 
            fill="none" 
            stroke={strokeColor}
            strokeWidth="8"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            strokeLinecap="round"
            className="transition-all duration-1000 ease-out"
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className={`text-5xl font-extrabold ${colorClass} tracking-tighter`}>{totalScore}</span>
          <span className="text-xs font-bold text-slate-400 uppercase mt-1">Total Score</span>
        </div>
      </div>
      
      {/* 뱃지 */}
      <div className={`absolute -bottom-3 left-1/2 transform -translate-x-1/2 px-4 py-1 rounded-full text-xs font-bold text-white shadow-md uppercase tracking-wide whitespace-nowrap
        ${totalScore >= 80 ? 'bg-emerald-500' : totalScore >= 50 ? 'bg-amber-500' : 'bg-rose-500'}
      `}>
        {statusText}
      </div>

      {/* 점수 항목 분석 */}
      <div className="mt-8 w-full text-sm text-slate-600 space-y-2 bg-slate-50 p-4 rounded-lg">
        <div className="flex justify-between items-center">
          <span>🏢 국세청:</span>
          <span className="font-bold text-slate-800">{score.breakdown.nts}점</span>
        </div>
        <div className="flex justify-between items-center">
          <span>⚖️ 공정위:</span>
          <span className="font-bold text-slate-800">{score.breakdown.ftc}점</span>
        </div>
        <div className="flex justify-between items-center">
          <span>®️ 특허청:</span>
          <span className="font-bold text-slate-800">{score.breakdown.kipris}점</span>
        </div>
      </div>
    </div>
  );
}

// 리스트 아이템 컴포넌트
function ResultItem({ label, value, isGood, icon }: { label: string, value: string, isGood: boolean, icon: string }) {
  return (
    <div className="flex justify-between items-center p-4 bg-slate-50 border border-slate-200 rounded-xl hover:bg-white hover:shadow-sm transition-all duration-200">
      <div className="flex items-center space-x-3">
        <span className="text-xl">{icon}</span>
        <span className="text-slate-600 font-medium text-sm">{label}</span>
      </div>
      <div className="flex items-center space-x-2">
        <span className={`text-sm font-bold ${isGood ? 'text-emerald-600' : 'text-slate-500'}`}>
          {value}
        </span>
        {isGood && (
          <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className="w-5 h-5 text-emerald-500">
            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.857-9.809a.75.75 0 00-1.214-.882l-3.483 4.79-1.88-1.88a.75.75 0 10-1.06 1.061l2.5 2.5a.75.75 0 001.137-.089l4-5.5z" clipRule="evenodd" />
          </svg>
        )}
      </div>
    </div>
  );
}